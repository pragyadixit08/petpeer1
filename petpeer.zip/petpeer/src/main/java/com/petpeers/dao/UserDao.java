package com.petpeers.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.petpeers.entity.UserEntity;
import com.petpeers.repository.UserRepo;

@Component
public class UserDao {

	@Autowired
	UserRepo userRepo;

	public List<UserEntity> findAll() {
		return userRepo.findAll();
	}

	public UserEntity save(UserEntity userEntity) {
		return userRepo.save(userEntity);
	}

}