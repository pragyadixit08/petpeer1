package com.petpeers.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.petpeers.entity.PetEntity;
import com.petpeers.entity.UserEntity;
import com.petpeers.repository.PetRepo;

public class PetDao {

	@Autowired
	PetRepo petRepo;

	public List<PetEntity> findAll() {
		return petRepo.findAll();
	}

	public PetEntity save(PetEntity petEntity) {
		return petRepo.save(petEntity);
	}

	public PetEntity findMyPets(UserEntity userId) {
		return petRepo.findByPetOwnerId(userId);
	}

}