package com.petpeers.repository;



import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;



import com.petpeers.entity.PetEntity;
import com.petpeers.entity.UserEntity;
import com.petpeers.model.Pet;



@Repository
public interface PetRepo extends JpaRepository<PetEntity, Long> {



PetEntity findByPetOwnerId(UserEntity userId);



}