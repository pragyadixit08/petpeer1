package com.petpeers.entity;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "pets")
public class PetEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	@Column(name = "PET_NAME")
	private String petName;
	@Column(name = "PET_AGE")
	private Integer petAge;
	@Column(name = "PET_PLACE")
	private String petPlace;
	@Column(name = "PET_OWNERID")
	@OneToMany(mappedBy = "id")
	private Set<UserEntity> petOwnerId;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getPetName() {
		return petName;
	}

	public void setPetName(String petName) {
		this.petName = petName;
	}

	public Integer getPetAge() {
		return petAge;
	}

	public void setPetAge(Integer petAge) {
		this.petAge = petAge;
	}

	public String getPetPlace() {
		return petPlace;
	}

	public void setPetPlace(String petPlace) {
		this.petPlace = petPlace;
	}

	public Set<UserEntity> getPetOwnerId() {
		return petOwnerId;
	}

	public void setPetOwnerId(Set<UserEntity> petOwnerId) {
		this.petOwnerId = petOwnerId;
	}

	@Override
	public String toString() {
		return "PetEntity [id=" + id + ", petName=" + petName + ", petAge=" + petAge + ", petPlace=" + petPlace
				+ ", petOwnerId=" + petOwnerId + "]";
	}

}