package com.petpeers.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.petpeers.dao.UserDao;
import com.petpeers.entity.UserEntity;
import com.petpeers.model.User;

@Component
public class UserService {

	@Autowired
	UserDao userDao;
	@Autowired
	private user.validation.UserValidation userValidation;

	public Object addUser(User user) {

		String msg = userValidation.validate(user);
		if (msg.equals("Success")) {
			UserEntity userEntity = new UserEntity();
			userEntity.setId(Long.valueOf(0));
			userEntity.setUsername(user.getUsername());
			userEntity.setUserPassword(user.getUserPassword());
			return userDao.save(userEntity);
		}
		return msg;
	}

	public List<UserEntity> listUsers() {
		return userDao.findAll();
	}

}