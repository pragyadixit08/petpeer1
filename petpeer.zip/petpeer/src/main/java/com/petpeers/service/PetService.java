package com.petpeers.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.petpeers.dao.PetDao;
import com.petpeers.entity.PetEntity;
import com.petpeers.entity.UserEntity;
import com.petpeers.model.Pet;


@Service
public class PetService {

	@Autowired
	PetDao petDao;

	public List<PetEntity> getAllPets() {
		return petDao.findAll();
	}

	public PetEntity savePet(Pet model) {
		PetEntity petEntity = new PetEntity();
		petEntity.setPetAge(model.getAge());
		petEntity.setPetName(model.getName());
		petEntity.setPetPlace(model.getPlace());

		return petDao.save(petEntity);
	}

	public Object myPets(Long userId) {
		UserEntity entity = new UserEntity();
		entity.setId(userId);
		PetEntity petEntity = petDao.findMyPets(entity);
		if (petEntity == null) {
			return "Pet owner not available for " + userId;
		} else {
			return petEntity;
		}
	}

}