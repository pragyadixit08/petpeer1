package com.petpeers.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.petpeers.entity.UserEntity;
import com.petpeers.model.User;
import com.petpeers.service.UserService;


@RestController
@CrossOrigin
public class UsersController {

	@Autowired
	private UserService userService;

	@PostMapping(value = "/user/add")
	public Object addUser(@RequestBody User user) {
		System.out.println(user.toString());
		return userService.addUser(user);

	}

	@GetMapping(value = "/users")
	public List<UserEntity> listUsers() {
		return userService.listUsers();

	}

}