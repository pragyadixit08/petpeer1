package com.petpeers.controller;



import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;



import com.petpeers.entity.PetEntity;
import com.petpeers.entity.UserEntity;
import com.petpeers.model.Pet;
import com.petpeers.service.PetService;
import com.petpeers.service.UserService;



@RestController
public class PetController {

@Autowired
private PetService petService;

@GetMapping(value ="/pets")
public List<PetEntity> petHome() {
return petService.getAllPets();

}

@PostMapping(value ="/savePet")
public PetEntity savePet(@RequestBody Pet pet) {
System.out.println(pet.toString());
return petService.savePet(pet);

}

@GetMapping(value ="/pets/myPets")
@CrossOrigin
public Object myPets(@RequestParam String userId) {
System.out.println("userId="+userId);
return petService.myPets(Long.valueOf(userId));

}
}