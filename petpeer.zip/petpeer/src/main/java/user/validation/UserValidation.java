package user.validation;

import org.springframework.stereotype.Component;

import com.petpeers.model.User;

@Component
public class UserValidation {

	public String  validate(User user) {
		if (user.getUserPassword().equals(user.getConfirmPassword())) {
			return "Success";
		}
		return "Password does not match";
	}

}